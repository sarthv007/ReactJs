<?php

	$about = array(
		'name' => 'Nederlands',
		'author' => array(
			'name' => 'Carsten de Vries',
			'email' => 'carsten@vrieswerk.nl',
			'website' => 'http://www.vrieswerk.nl'
		),
		'release-date' => '2009-11-09'
	);
	
	
	/*
	 * EXTENSION: Maintenance Mode
	 * Localisation strings
	 */

	$dictionary = array(
	
		'Maintenance Mode' => 
		false,

		'Enable maintenance mode' => 
		false,

		'Maintenance mode will redirect all visitors, other than developers, to the specified maintenance page.' => 
		false,

		'This site is currently in maintenance mode.' =>
		false,
		
		'Restore?' =>
		false,

		'Website Offline' => 
		false,

		'This site is currently in maintenance. Please check back at a later date.' => 
		false

	);
