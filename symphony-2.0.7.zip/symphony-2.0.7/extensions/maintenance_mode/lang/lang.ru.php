<?php

	$about = array(
		'name' => 'Русский',
		'author' => array(
			'name' => 'Igor Bogdanov',
			'email' => 'i.bogdanov@ibcico.com',
			'website' => false
		),
		'release-date' => '2009-11-27'
	);
	
	
	/*
	 * EXTENSION: Maintenance Mode
	 * Localisation strings
	 */

	$dictionary = array(
	
		'Maintenance Mode' => 
		false,

		'Enable maintenance mode' => 
		false,

		'Maintenance mode will redirect all visitors, other than developers, to the specified maintenance page.' => 
		false,

		'This site is currently in maintenance mode.' =>
		false,
		
		'Restore?' =>
		false,

		'Website Offline' => 
		false,

		'This site is currently in maintenance. Please check back at a later date.' => 
		false

	);
