<?php

	$about = array(
		'name' => 'Portuguese (Brazil)',
		'author' => array(
			'name' => 'Rainer Borene',
			'email' => 'rainerborene@gmail.com',
			'website' => false
		),
		'release-date' => '2009-10-08'
	);
	
	
	/*
	 * EXTENSION: Maintenance Mode
	 * Localisation strings
	 */

	$dictionary = array(
	
		'Maintenance Mode' => 
		false,

		'Enable maintenance mode' => 
		false,

		'Maintenance mode will redirect all visitors, other than developers, to the specified maintenance page.' => 
		false,

		'This site is currently in maintenance mode.' =>
		false,
		
		'Restore?' =>
		false,

		'Website Offline' => 
		false,

		'This site is currently in maintenance. Please check back at a later date.' => 
		false

	);
