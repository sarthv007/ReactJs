<?php

	$about = array(
		'name' => 'Portuguese (Brazil)',
		'author' => array(
			'name' => 'Rainer Borene',
			'email' => 'eu@rainerborene.com',
			'website' => false
		),
		'release-date' => '2010-02-01'
	);


	/*
	 * EXTENSION: Field: Select Box Link
	 * Localisation strings
	 */

	$dictionary = array(

		'Select Box Link' => 
		'Select Box Link',

		'None' =>
		'Nenhum',

		'Options' => 
		'Opções',

		'Limit to the %s most recent entries' => 
		'Limitar para as %s recentes entradas',

		'Allow selection of multiple options' => 
		'Permitir seleção de múltiplas opções'

	);
	