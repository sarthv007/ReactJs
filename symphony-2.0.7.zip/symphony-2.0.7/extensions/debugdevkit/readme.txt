Debug Devkit
-------------------------------------------------------------------------------

Version: 1.0.5
Author: Rowan Lewis <rowan@pixelcarnage.com>
Build Date: 1 December 2009
Requirements: Symphony 2.0.4